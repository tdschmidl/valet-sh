valet.sh
========

Installation
------------

```bash
bash <(curl -s https://raw.githubusercontent.com/valet-sh/valet-sh/master/valet.sh) install
```

Usage
-----
tbd.

Credits
-------
tbd.



